<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

function repo_seed_data(): array
{
    static $data = null;

    if (is_array($data)) {
        return $data;
    }

    $data = require __DIR__ . '/../config/data.php';
    return $data;
}

function repo_storage_path(string $fileName): string
{
    return __DIR__ . '/../storage/' . $fileName;
}

function repo_read_storage_array(string $fileName): array
{
    $path = repo_storage_path($fileName);

    if (!is_file($path)) {
        return [];
    }

    $raw = file_get_contents($path);
    if ($raw === false || $raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function repo_write_storage_array(string $fileName, array $payload): bool
{
    $path = repo_storage_path($fileName);
    $encoded = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($encoded === false) {
        return false;
    }

    return file_put_contents($path, $encoded) !== false;
}

function repo_filter_courses(array $courses, string $tag): array
{
    if ($tag === '' || strcasecmp($tag, 'all') === 0) {
        return array_values($courses);
    }

    return array_values(array_filter(
        $courses,
        static fn(array $course): bool => isset($course['tag']) && strcasecmp((string) $course['tag'], $tag) === 0
    ));
}

function repo_get_storage_courses(): array
{
    $storedCourses = repo_read_storage_array('courses.json');
    if ($storedCourses !== []) {
        return $storedCourses;
    }

    $data = repo_seed_data();
    return $data['courses'] ?? [];
}

function repo_course_media_index(): array
{
    static $index = null;

    if (is_array($index)) {
        return $index;
    }

    $index = [];
    foreach (repo_get_storage_courses() as $course) {
        $courseId = (int) ($course['id'] ?? 0);
        if ($courseId <= 0) {
            continue;
        }

        $index[$courseId] = [
            'image' => isset($course['image']) ? (string) $course['image'] : '',
            'video' => isset($course['video']) ? (string) $course['video'] : '',
        ];
    }

    return $index;
}

function repo_apply_course_media(array $course): array
{
    $courseId = (int) ($course['id'] ?? 0);
    $media = repo_course_media_index()[$courseId] ?? ['image' => '', 'video' => ''];

    if (!isset($course['image']) || trim((string) $course['image']) === '') {
        $course['image'] = (string) ($media['image'] ?? '');
    }

    if (!isset($course['video']) || trim((string) $course['video']) === '') {
        $course['video'] = (string) ($media['video'] ?? '');
    }

    return $course;
}

function repo_get_course_by_id(int $courseId): ?array
{
    if ($courseId <= 0) {
        return null;
    }

    foreach (repo_get_courses('All') as $course) {
        if ((int) ($course['id'] ?? 0) === $courseId) {
            return $course;
        }
    }

    return null;
}

function repo_enrich_enrollments_with_media(array $enrollments): array
{
    $mediaIndex = repo_course_media_index();

    return array_values(array_map(
        static function (array $enrollment) use ($mediaIndex): array {
            $courseId = (int) ($enrollment['course_id'] ?? 0);
            $media = $mediaIndex[$courseId] ?? ['image' => '', 'video' => ''];

            if (!isset($enrollment['course_image']) || trim((string) $enrollment['course_image']) === '') {
                $enrollment['course_image'] = (string) ($media['image'] ?? '');
            }

            if (!isset($enrollment['course_video']) || trim((string) $enrollment['course_video']) === '') {
                $enrollment['course_video'] = (string) ($media['video'] ?? '');
            }

            return $enrollment;
        },
        $enrollments
    ));
}

function repo_get_courses(string $tag = 'All'): array
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'courses')) {
        if ($tag !== '' && strcasecmp($tag, 'all') !== 0) {
            $statement = $pdo->prepare(
                'SELECT id, emoji, bg, tag, title, instructor, duration, students, price, original, rating FROM courses WHERE tag = :tag ORDER BY id ASC'
            );
            $statement->execute(['tag' => $tag]);
            $rows = $statement->fetchAll() ?: [];
            return array_values(array_map('repo_apply_course_media', $rows));
        }

        $statement = $pdo->query(
            'SELECT id, emoji, bg, tag, title, instructor, duration, students, price, original, rating FROM courses ORDER BY id ASC'
        );
        $rows = $statement->fetchAll() ?: [];
        return array_values(array_map('repo_apply_course_media', $rows));
    }

    $courses = array_values(array_map('repo_apply_course_media', repo_get_storage_courses()));
    return repo_filter_courses($courses, $tag);
}

function repo_get_stats(): array
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'stats')) {
        $statement = $pdo->query('SELECT metric_key, metric_value FROM stats');
        $rows = $statement->fetchAll() ?: [];
        $stats = [];

        foreach ($rows as $row) {
            $key = isset($row['metric_key']) ? (string) $row['metric_key'] : '';
            $value = isset($row['metric_value']) ? (string) $row['metric_value'] : '';

            if ($key !== '') {
                $stats[$key] = $value;
            }
        }

        return $stats;
    }

    $data = repo_seed_data();
    return $data['stats'] ?? [];
}

function repo_get_categories(): array
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'categories')) {
        $statement = $pdo->query('SELECT name, course_count AS count FROM categories ORDER BY name ASC');
        return $statement->fetchAll() ?: [];
    }

    $data = repo_seed_data();
    return $data['categories'] ?? [];
}

function repo_create_user(string $name, string $email, string $password): array
{
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    if ($passwordHash === false) {
        return ['ok' => false, 'message' => 'Failed to hash password.'];
    }

    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'users')) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $check->execute(['email' => $email]);

        if ($check->fetch()) {
            return ['ok' => false, 'message' => 'Email already registered.'];
        }

        $insert = $pdo->prepare(
            'INSERT INTO users (name, email, password_hash) VALUES (:name, :email, :password_hash)'
        );
        $insert->execute([
            'name' => $name,
            'email' => $email,
            'password_hash' => $passwordHash,
        ]);

        return ['ok' => true, 'message' => 'User created.'];
    }

    $users = repo_read_storage_array('users.json');

    foreach ($users as $user) {
        if (isset($user['email']) && strcasecmp((string) $user['email'], $email) === 0) {
            return ['ok' => false, 'message' => 'Email already registered.'];
        }
    }

    $users[] = [
        'id' => count($users) + 1,
        'name' => $name,
        'email' => $email,
        'password_hash' => $passwordHash,
        'created_at' => date(DATE_ATOM),
    ];

    if (!repo_write_storage_array('users.json', $users)) {
        return ['ok' => false, 'message' => 'Failed to write user data.'];
    }

    return ['ok' => true, 'message' => 'User created.'];
}

function repo_verify_user(string $email, string $password): ?array
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'users')) {
        $statement = $pdo->prepare('SELECT id, name, email, password_hash FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => $email]);
        $user = $statement->fetch();

        if (!$user || !isset($user['password_hash'])) {
            return null;
        }

        if (!password_verify($password, (string) $user['password_hash'])) {
            return null;
        }

        return [
            'id' => (int) ($user['id'] ?? 0),
            'name' => (string) ($user['name'] ?? ''),
            'email' => (string) ($user['email'] ?? ''),
        ];
    }

    $users = repo_read_storage_array('users.json');

    foreach ($users as $user) {
        if (!isset($user['email'], $user['password_hash'])) {
            continue;
        }

        if (strcasecmp((string) $user['email'], $email) !== 0) {
            continue;
        }

        if (!password_verify($password, (string) $user['password_hash'])) {
            return null;
        }

        return [
            'id' => (int) ($user['id'] ?? 0),
            'name' => (string) ($user['name'] ?? ''),
            'email' => (string) ($user['email'] ?? ''),
        ];
    }

    return null;
}

function repo_create_enrollment(string $email, int $courseId, string $courseTitle): bool
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'enrollments')) {
        $statement = $pdo->prepare(
            'INSERT INTO enrollments (user_email, course_id, course_title) VALUES (:user_email, :course_id, :course_title)'
        );

        return $statement->execute([
            'user_email' => $email,
            'course_id' => $courseId,
            'course_title' => $courseTitle,
        ]);
    }

    $enrollments = repo_read_storage_array('enrollments.json');
    $course = repo_get_course_by_id($courseId);
    $enrollments[] = [
        'id' => count($enrollments) + 1,
        'user_email' => $email,
        'course_id' => $courseId,
        'course_title' => $courseTitle,
        'course_image' => (string) ($course['image'] ?? ''),
        'course_video' => (string) ($course['video'] ?? ''),
        'created_at' => date(DATE_ATOM),
    ];

    return repo_write_storage_array('enrollments.json', $enrollments);
}

function repo_get_enrollments(string $email): array
{
    $pdo = get_database_connection();

    if ($pdo instanceof PDO && db_table_exists($pdo, 'enrollments')) {
        $statement = $pdo->prepare(
            'SELECT id, user_email, course_id, course_title, created_at FROM enrollments WHERE user_email = :user_email ORDER BY id DESC'
        );
        $statement->execute(['user_email' => $email]);
        $rows = $statement->fetchAll() ?: [];
        return repo_enrich_enrollments_with_media($rows);
    }

    $enrollments = repo_read_storage_array('enrollments.json');

    $records = array_values(array_filter(
        $enrollments,
        static fn(array $enrollment): bool => isset($enrollment['user_email'])
            && strcasecmp((string) $enrollment['user_email'], $email) === 0
    ));

    return repo_enrich_enrollments_with_media($records);
}
?>
