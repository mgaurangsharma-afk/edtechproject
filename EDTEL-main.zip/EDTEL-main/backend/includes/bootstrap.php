<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function send_json(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function send_error(string $message, int $statusCode = 400, array $extra = []): void
{
    send_json([
        'ok' => false,
        'message' => $message,
        'error' => $extra,
    ], $statusCode);
}

function require_http_method(string $method): void
{
    $currentMethod = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $expectedMethod = strtoupper($method);

    if ($currentMethod !== $expectedMethod) {
        send_error('Method not allowed.', 405, [
            'expected' => $expectedMethod,
            'received' => $currentMethod,
        ]);
    }
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');

    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        send_error('Invalid JSON payload.', 400);
    }

    return $decoded;
}
