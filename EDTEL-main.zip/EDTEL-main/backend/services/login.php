<?php

declare(strict_types=1);

$_GET['service'] = 'login';
require __DIR__ . '/../api.php';
?>
