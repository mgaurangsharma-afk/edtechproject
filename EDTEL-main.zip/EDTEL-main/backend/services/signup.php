<?php

declare(strict_types=1);

$_GET['service'] = 'signup';
require __DIR__ . '/../api.php';
?>
