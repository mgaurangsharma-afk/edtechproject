<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/repository.php';

$stats = repo_get_stats();

send_json([
    'ok' => true,
    'data' => $stats,
]);
?>
