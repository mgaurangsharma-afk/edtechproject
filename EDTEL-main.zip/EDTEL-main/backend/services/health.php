<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

send_json([
    'ok' => true,
    'data' => [
        'service' => 'edtel-backend',
        'status' => 'up',
        'timestamp' => date(DATE_ATOM),
    ],
]);
?>
