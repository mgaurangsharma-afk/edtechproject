<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/repository.php';

$categories = repo_get_categories();

send_json([
    'ok' => true,
    'data' => $categories,
]);
?>
