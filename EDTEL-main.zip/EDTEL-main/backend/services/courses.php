<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/repository.php';

$tag = isset($_GET['tag']) ? trim((string) $_GET['tag']) : 'All';
$courses = repo_get_courses($tag);

send_json([
    'ok' => true,
    'data' => $courses,
    'meta' => [
        'count' => count($courses),
        'filter' => $tag,
    ],
]);
?>
