<?php

declare(strict_types=1);

$_GET['service'] = 'enroll';
require __DIR__ . '/../api.php';
?>
