SET NAMES utf8mb4;

INSERT INTO courses (id, emoji, bg, tag, title, instructor, duration, students, price, original, rating) VALUES
  (1, '⚛️', 'rgba(59,130,246,0.12)', 'Development', 'React & Next.js: Complete Developer Guide', 'Alex Rivera', '28h', '42k', '$89', '$149', '4.9'),
  (2, '🎨', 'rgba(236,72,153,0.12)', 'Design', 'UI/UX Design Masterclass 2025', 'Sarah Chen', '22h', '35k', '$79', '$129', '4.8'),
  (3, '🤖', 'rgba(139,92,246,0.12)', 'AI & ML', 'Machine Learning A-Z with Python', 'Marcus Obi', '40h', '61k', '$99', '$179', '4.9'),
  (4, '📊', 'rgba(34,211,165,0.12)', 'Data Science', 'Python for Data Science & Visualization', 'Priya Mehta', '32h', '28k', '$85', '$139', '4.7'),
  (5, '🚀', 'rgba(245,158,11,0.12)', 'Development', 'Node.js & Express: Backend Bootcamp', 'Alex Rivera', '18h', '19k', '$69', '$119', '4.8'),
  (6, '💼', 'rgba(16,185,129,0.12)', 'Business', 'Startup Fundamentals & Growth Strategy', 'Jordan Lee', '14h', '24k', '$59', '$99', '4.6')
ON DUPLICATE KEY UPDATE
  emoji = VALUES(emoji),
  bg = VALUES(bg),
  tag = VALUES(tag),
  title = VALUES(title),
  instructor = VALUES(instructor),
  duration = VALUES(duration),
  students = VALUES(students),
  price = VALUES(price),
  original = VALUES(original),
  rating = VALUES(rating);

INSERT INTO stats (metric_key, metric_value) VALUES
  ('learners', '2M+'),
  ('courses', '1,200+'),
  ('instructors', '350+'),
  ('rating', '4.9★')
ON DUPLICATE KEY UPDATE
  metric_value = VALUES(metric_value);

INSERT INTO categories (name, course_count) VALUES
  ('Development', 420),
  ('Design', 186),
  ('Data Science', 238),
  ('Business', 310),
  ('Marketing', 142),
  ('AI & ML', 198),
  ('Photography', 94),
  ('Finance', 175)
ON DUPLICATE KEY UPDATE
  course_count = VALUES(course_count);
