<?php

declare(strict_types=1);

function get_database_connection(): ?PDO
{
    static $pdo = false;

    if ($pdo !== false) {
        return $pdo;
    }

    $host = trim((string) (getenv('DB_HOST') ?: '127.0.0.1'));
    $port = trim((string) (getenv('DB_PORT') ?: '3306'));
    $name = trim((string) (getenv('DB_NAME') ?: 'edtel'));
    $user = trim((string) (getenv('DB_USER') ?: 'root'));
    $pass = (string) (getenv('DB_PASS') ?: '');

    if ($host === '' || $name === '' || $user === '') {
        $pdo = null;
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $host, $port, $name);

    try {
        $pdo = new PDO(
            $dsn,
            $user,
            $pass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    } catch (Throwable $exception) {
        $pdo = null;
    }

    return $pdo;
}

function db_table_exists(PDO $pdo, string $tableName): bool
{
    $statement = $pdo->prepare('SHOW TABLES LIKE :tableName');
    $statement->execute(['tableName' => $tableName]);
    return (bool) $statement->fetchColumn();
}
?>
