<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/repository.php';

$service = isset($_GET['service']) ? strtolower(trim((string) $_GET['service'])) : 'health';

$sessionUser = isset($_SESSION['user']) && is_array($_SESSION['user'])
    ? $_SESSION['user']
    : null;
$sessionEmail = isset($sessionUser['email']) ? strtolower(trim((string) $sessionUser['email'])) : '';

switch ($service) {
    case 'courses': {
            require_http_method('GET');
            $tag = isset($_GET['tag']) ? trim((string) $_GET['tag']) : 'All';
            $courses = repo_get_courses($tag);

            send_json([
                'ok' => true,
                'data' => $courses,
                'meta' => [
                    'count' => count($courses),
                    'filter' => $tag,
                ],
            ]);
        }

    case 'stats': {
            require_http_method('GET');

            send_json([
                'ok' => true,
                'data' => repo_get_stats(),
            ]);
        }

    case 'categories': {
            require_http_method('GET');

            send_json([
                'ok' => true,
                'data' => repo_get_categories(),
            ]);
        }

    case 'health': {
            require_http_method('GET');

            send_json([
                'ok' => true,
                'data' => [
                    'service' => 'edtel-backend',
                    'status' => 'up',
                    'timestamp' => date(DATE_ATOM),
                ],
            ]);
        }

    case 'register':
    case 'signup': {
            require_http_method('POST');

            $body = read_json_body();
            $name = trim((string) ($body['name'] ?? ''));
            $email = strtolower(trim((string) ($body['email'] ?? '')));
            $password = (string) ($body['password'] ?? '');

            if ($name === '' || $email === '' || $password === '') {
                send_error('Name, email, and password are required.', 422);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                send_error('A valid email is required.', 422);
            }

            if (strlen($password) < 6) {
                send_error('Password must be at least 6 characters.', 422);
            }

            $result = repo_create_user($name, $email, $password);
            if (!($result['ok'] ?? false)) {
                send_error((string) ($result['message'] ?? 'Unable to create user.'), 409);
            }

            $_SESSION['user'] = [
                'name' => $name,
                'email' => $email,
            ];
            session_regenerate_id(true);

            send_json([
                'ok' => true,
                'message' => 'Signup successful.',
                'data' => [
                    'name' => $name,
                    'email' => $email,
                ],
            ], 201);
        }

    case 'login': {
            require_http_method('POST');

            $body = read_json_body();
            $email = strtolower(trim((string) ($body['email'] ?? '')));
            $password = (string) ($body['password'] ?? '');

            if ($email === '' || $password === '') {
                send_error('Email and password are required.', 422);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                send_error('A valid email is required.', 422);
            }

            $user = repo_verify_user($email, $password);
            if ($user === null) {
                send_error('Invalid email or password.', 401);
            }

            $_SESSION['user'] = [
                'name' => (string) ($user['name'] ?? ''),
                'email' => strtolower(trim((string) ($user['email'] ?? ''))),
            ];
            session_regenerate_id(true);

            send_json([
                'ok' => true,
                'message' => 'Login successful.',
                'data' => $user,
            ]);
        }

    case 'profile': {
            require_http_method('GET');

            if ($sessionEmail === '') {
                send_error('Please login to continue.', 401);
            }

            send_json([
                'ok' => true,
                'data' => [
                    'name' => (string) ($sessionUser['name'] ?? ''),
                    'email' => $sessionEmail,
                ],
            ]);
        }

    case 'logout': {
            if (!in_array($_SERVER['REQUEST_METHOD'] ?? '', ['GET', 'POST'], true)) {
                send_error('Method not allowed.', 405, [
                    'expected' => 'GET or POST',
                    'received' => strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN')),
                ]);
            }

            $_SESSION = [];

            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool) $params['secure'], (bool) $params['httponly']);
            }

            session_destroy();

            send_json([
                'ok' => true,
                'message' => 'Logged out successfully.',
            ]);
        }

    case 'enroll': {
            require_http_method('POST');

            $body = read_json_body();
            $email = $sessionEmail !== ''
                ? $sessionEmail
                : strtolower(trim((string) ($body['email'] ?? '')));
            $courseId = (int) ($body['course_id'] ?? 0);
            $courseTitle = trim((string) ($body['course_title'] ?? ''));

            if ($email === '' || $courseId <= 0 || $courseTitle === '') {
                send_error('Please login and provide course_id and course_title.', 422);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                send_error('A valid email is required.', 422);
            }

            $saved = repo_create_enrollment($email, $courseId, $courseTitle);
            if (!$saved) {
                send_error('Unable to save enrollment.', 500);
            }

            $course = repo_get_course_by_id($courseId);

            send_json([
                'ok' => true,
                'message' => 'Enrollment successful.',
                'data' => [
                    'email' => $email,
                    'course_id' => $courseId,
                    'course_title' => $courseTitle,
                    'course_image' => (string) ($course['image'] ?? ''),
                    'course_video' => (string) ($course['video'] ?? ''),
                ],
            ], 201);
        }

    case 'enrollments': {
            require_http_method('GET');

            $email = $sessionEmail !== ''
                ? $sessionEmail
                : strtolower(trim((string) ($_GET['email'] ?? '')));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                send_error('Please login to view enrollments.', 401);
            }

            $enrollments = repo_get_enrollments($email);

            send_json([
                'ok' => true,
                'data' => $enrollments,
                'meta' => [
                    'count' => count($enrollments),
                ],
            ]);
        }

    default:
        send_error('Unknown service.', 404, ['service' => $service]);
}
