function resolveSignupRedirectTarget() {
    const redirectQuery = appAuth.getQueryParam('redirect');
    const target = appAuth.sanitizeRedirectTarget(redirectQuery, 'dashboard.php');

    if (/^(login|signup)\.php($|[?#])/i.test(target)) {
        return 'dashboard.php';
    }

    return target;
}

const signupForm = document.getElementById('signupForm');
const signupStatus = document.getElementById('signupStatus');
const signupNotice = document.getElementById('signupNotice');
const signupSubmitBtn = document.getElementById('signupSubmitBtn');
const loginLink = document.getElementById('loginLink');

const signupRedirectTarget = resolveSignupRedirectTarget();
const signupNoticeMessage = appAuth.getQueryParam('message');

if (signupNoticeMessage) {
    signupNotice.hidden = false;
    signupNotice.textContent = signupNoticeMessage;
}

if (loginLink) {
    const params = new URLSearchParams();
    params.set('redirect', signupRedirectTarget);
    loginLink.href = `login.php?${params.toString()}`;
}

signupForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(signupForm);
    const name = String(formData.get('name') || '').trim();
    const email = String(formData.get('email') || '').trim().toLowerCase();
    const password = String(formData.get('password') || '');

    signupStatus.classList.remove('error');
    signupStatus.textContent = 'Creating account...';
    signupSubmitBtn.disabled = true;

    try {
        const payload = await appAuth.postService('signup', {
            name,
            email,
            password,
        });

        const signedUser = payload && payload.data ? payload.data : { name, email };
        const signedEmail = signedUser && signedUser.email
            ? String(signedUser.email).trim().toLowerCase()
            : email;

        appAuth.setSessionUser({
            name: signedUser.name || name,
            email: signedEmail,
        });
        signupStatus.textContent = `Account created for ${signedEmail}. Redirecting...`;

        setTimeout(() => {
            window.location.href = signupRedirectTarget;
        }, 350);
    } catch (error) {
        signupStatus.textContent = error.message || 'Signup failed.';
        signupStatus.classList.add('error');
    } finally {
        signupSubmitBtn.disabled = false;
    }
});
