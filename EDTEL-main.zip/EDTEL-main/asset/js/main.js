const API_BASE = 'backend/api.php';
const USER_EMAIL_KEY = 'edtel_user_email';
const PENDING_COURSE_KEY = 'edtel_pending_course_id';

const fallbackCourses = [
  { id: 1, emoji: '⚛️', bg: 'rgba(59,130,246,0.12)', tag: 'Development', title: 'React & Next.js: Complete Developer Guide', instructor: 'Alex Rivera', duration: '28h', students: '42k', price: '$89', original: '$149', rating: '4.9' },
  { id: 2, emoji: '🎨', bg: 'rgba(236,72,153,0.12)', tag: 'Design', title: 'UI/UX Design Masterclass 2025', instructor: 'Sarah Chen', duration: '22h', students: '35k', price: '$79', original: '$129', rating: '4.8' },
  { id: 3, emoji: '🤖', bg: 'rgba(139,92,246,0.12)', tag: 'AI & ML', title: 'Machine Learning A-Z with Python', instructor: 'Marcus Obi', duration: '40h', students: '61k', price: '$99', original: '$179', rating: '4.9' },
  { id: 4, emoji: '📊', bg: 'rgba(34,211,165,0.12)', tag: 'Data Science', title: 'Python for Data Science & Visualization', instructor: 'Priya Mehta', duration: '32h', students: '28k', price: '$85', original: '$139', rating: '4.7' },
  { id: 5, emoji: '🚀', bg: 'rgba(245,158,11,0.12)', tag: 'Development', title: 'Node.js & Express: Backend Bootcamp', instructor: 'Alex Rivera', duration: '18h', students: '19k', price: '$69', original: '$119', rating: '4.8' },
  { id: 6, emoji: '💼', bg: 'rgba(16,185,129,0.12)', tag: 'Business', title: 'Startup Fundamentals & Growth Strategy', instructor: 'Jordan Lee', duration: '14h', students: '24k', price: '$59', original: '$99', rating: '4.6' },
];

let allCourses = [...fallbackCourses];
let activeFilter = 'All';
const nativeScrollTo = window.scrollTo.bind(window);

function getSessionUserEmail() {
  const sessionUser = window.__SESSION_USER__;
  if (!sessionUser || typeof sessionUser !== 'object') {
    return '';
  }

  return String(sessionUser.email || '').trim().toLowerCase();
}

function syncClientUserFromSession() {
  const sessionEmail = getSessionUserEmail();
  if (sessionEmail) {
    localStorage.setItem(USER_EMAIL_KEY, sessionEmail);
    return;
  }

  localStorage.removeItem(USER_EMAIL_KEY);
}

syncClientUserFromSession();

function getSignedInEmail() {
  const sessionEmail = getSessionUserEmail();
  if (sessionEmail) {
    return sessionEmail;
  }

  return (localStorage.getItem(USER_EMAIL_KEY) || '').trim().toLowerCase();
}

function sanitizeRedirectTarget(target, fallback = 'index.php') {
  const value = String(target || '').trim();
  if (!value) {
    return fallback;
  }

  if (/^https?:\/\//i.test(value) || value.startsWith('//')) {
    return fallback;
  }

  return value;
}

function redirectToLogin(message, redirectTarget) {
  const params = new URLSearchParams();
  if (message) {
    params.set('message', message);
  }

  params.set('redirect', sanitizeRedirectTarget(redirectTarget || 'index.php#courses', 'index.php#courses'));
  window.location.href = `login.php?${params.toString()}`;
}

function redirectToSignup(message, redirectTarget) {
  const params = new URLSearchParams();
  if (message) {
    params.set('message', message);
  }

  params.set('redirect', sanitizeRedirectTarget(redirectTarget || 'dashboard.php', 'dashboard.php'));
  window.location.href = `signup.php?${params.toString()}`;
}

function scrollTo(sectionIdOrX, y) {
  if (typeof sectionIdOrX === 'string') {
    const section = document.getElementById(sectionIdOrX);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
    return;
  }

  nativeScrollTo(sectionIdOrX, y);
}

async function fetchService(service, params = {}, options = {}) {
  const { method = 'GET', body = null } = options;
  const query = new URLSearchParams();
  query.set('service', service);

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      query.set(key, String(value));
    }
  });

  const queryString = query.toString();
  const url = queryString ? `${API_BASE}?${queryString}` : API_BASE;
  const requestOptions = {
    method,
    credentials: 'same-origin',
    headers: {
      Accept: 'application/json',
    },
  };

  if (body !== null) {
    requestOptions.headers['Content-Type'] = 'application/json';
    requestOptions.body = JSON.stringify(body);
  }

  const response = await fetch(url, requestOptions);

  let payload = null;
  try {
    payload = await response.json();
  } catch (error) {
    payload = null;
  }

  if (!response.ok || !payload || payload.ok === false) {
    const message = payload && typeof payload.message === 'string'
      ? payload.message
      : `Backend request failed with status ${response.status}`;
    throw new Error(message);
  }

  return payload;
}

function postService(service, payload) {
  return fetchService(service, {}, { method: 'POST', body: payload });
}

async function loadCoursesFromBackend() {
  try {
    const payload = await fetchService('courses');
    if (payload && payload.ok && Array.isArray(payload.data)) {
      allCourses = payload.data;
      renderCourses(activeFilter);
      lucide.createIcons();
    }
  } catch (error) {
    console.warn('Using fallback courses because backend request failed.', error);
  }
}

async function loadStatsFromBackend() {
  try {
    const payload = await fetchService('stats');
    if (!payload || !payload.ok || typeof payload.data !== 'object') {
      return;
    }

    const stats = payload.data;
    const map = {
      learners: 'statLearners',
      courses: 'statCourses',
      instructors: 'statInstructors',
      rating: 'statRating',
    };

    Object.entries(map).forEach(([key, elementId]) => {
      const element = document.getElementById(elementId);
      if (element && stats[key]) {
        element.textContent = stats[key];
      }
    });
  } catch (error) {
    console.warn('Stats service unavailable; keeping current values.', error);
  }
}

async function loadCategoriesFromBackend() {
  try {
    const payload = await fetchService('categories');
    if (!payload || !payload.ok || !Array.isArray(payload.data)) {
      return;
    }

    const countsByName = new Map(
      payload.data.map((item) => [String(item.name || '').trim().toLowerCase(), item.count])
    );

    document.querySelectorAll('.category-card').forEach((card) => {
      const nameElement = card.querySelector('.category-name');
      const countElement = card.querySelector('.category-count');

      if (!nameElement || !countElement) {
        return;
      }

      const key = nameElement.textContent.trim().toLowerCase();
      if (!countsByName.has(key)) {
        return;
      }

      countElement.textContent = `${countsByName.get(key)} courses`;
    });
  } catch (error) {
    console.warn('Category service unavailable; keeping current values.', error);
  }
}

async function hydrateFrontendFromBackend() {
  await Promise.all([
    loadCoursesFromBackend(),
    loadStatsFromBackend(),
    loadCategoriesFromBackend(),
  ]);
}

function renderCourses(filter) {
  const grid = document.getElementById('coursesGrid');
  const filtered = filter === 'All' ? allCourses : allCourses.filter((course) => course.tag === filter);

  const existing = new Map([...grid.children].map((el) => [parseInt(el.dataset.id, 10), el]));

  filtered.forEach((course) => {
    if (existing.has(course.id)) {
      existing.delete(course.id);
    } else {
      const card = createCourseCard(course);
      grid.appendChild(card);
    }
  });

  existing.forEach((el) => el.remove());

  filtered.forEach((course) => {
    const element = grid.querySelector(`[data-id="${course.id}"]`);
    if (element) {
      grid.appendChild(element);
    }
  });

  if (filtered.length === 0) {
    grid.innerHTML = '<div style="color:var(--muted);font-size:0.9rem;padding:2rem;grid-column:1/-1;text-align:center;">No courses in this category yet. Check back soon!</div>';
  }
}

function createCourseCard(course) {
  const div = document.createElement('div');
  div.className = 'course-card';
  div.dataset.id = course.id;
  div.innerHTML = `
    <div class="course-thumb" style="background:${course.bg};">
      <span>${course.emoji}</span>
      <span class="course-tag">${course.tag}</span>
    </div>
    <div class="course-body">
      <div class="course-meta">
        <span><i data-lucide="clock" style="width:11px;height:11px;"></i> ${course.duration}</span>
        <span><i data-lucide="users" style="width:11px;height:11px;"></i> ${course.students}</span>
        <span style="color:#f59e0b;">★ ${course.rating}</span>
      </div>
      <div class="course-title">${course.title}</div>
      <div style="font-size:0.78rem;color:var(--muted);margin-bottom:0.75rem;">by ${course.instructor}</div>
      <div class="course-footer">
        <div class="course-price">${course.price}<span class="original">${course.original}</span></div>
        <button class="enroll-btn" onclick="handleEnroll(event, ${course.id})">Enroll</button>
      </div>
    </div>`;

  return div;
}

async function handleEnroll(event, courseId) {
  event.stopPropagation();

  const course = allCourses.find((item) => Number(item.id) === Number(courseId));
  if (!course) {
    showToast('Unable to find selected course.');
    return;
  }

  const email = getSignedInEmail();
  if (!email) {
    localStorage.setItem(PENDING_COURSE_KEY, String(course.id));
    redirectToLogin('Please login to enroll in this course.', 'index.php#courses');
    return;
  }

  try {
    await postService('enroll', {
      email,
      course_id: Number(course.id),
      course_title: course.title,
    });
    showToast(`Enrolled in "${course.title.substring(0, 28)}..." ✅`);
  } catch (error) {
    showToast(error.message || 'Enrollment failed.');
  }
}

async function processPendingEnrollment() {
  const pendingCourseId = localStorage.getItem(PENDING_COURSE_KEY);
  const email = getSignedInEmail();

  if (!pendingCourseId || !email) {
    return;
  }

  const course = allCourses.find((item) => Number(item.id) === Number(pendingCourseId));
  localStorage.removeItem(PENDING_COURSE_KEY);

  if (!course) {
    return;
  }

  try {
    await postService('enroll', {
      email,
      course_id: Number(course.id),
      course_title: course.title,
    });
    showToast(`Enrollment saved for ${email}`);
  } catch (error) {
    showToast(error.message || 'Could not complete pending enrollment.');
  }
}

function setTab(button, filter) {
  document.querySelectorAll('.tab-btn').forEach((tab) => tab.classList.remove('active'));
  button.classList.add('active');
  activeFilter = filter;
  renderCourses(filter);
  lucide.createIcons();
}

function filterCourses(category) {
  document.getElementById('courses').scrollIntoView({ behavior: 'smooth' });

  setTimeout(() => {
    const button = [...document.querySelectorAll('.tab-btn')].find((tab) => tab.textContent.trim() === category);
    if (button) {
      setTab(button, category);
      return;
    }

    document.querySelectorAll('.tab-btn').forEach((tab) => tab.classList.remove('active'));
    document.querySelector('.tab-btn').classList.add('active');
    renderCourses('All');
    lucide.createIcons();
  }, 500);
}

let toastTimeout;
function showToast(message) {
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toastMsg');
  toastMessage.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 3000);
}

function handleSignupPrompt() {
  redirectToSignup('Create your account to continue.', 'dashboard.php');
}

function handleLoginPrompt() {
  redirectToLogin('Please login to continue.', 'dashboard.php');
}

function handleGetStartedAction() {
  const email = getSignedInEmail();
  if (!email) {
    redirectToLogin('Please login to get started for free.', 'dashboard.php');
    return;
  }

  window.location.href = 'dashboard.php';
}

function handleBrowseCoursesAction() {
  const coursesSection = document.getElementById('courses');
  if (coursesSection) {
    coursesSection.scrollIntoView({ behavior: 'smooth' });
  }

  const allTab = [...document.querySelectorAll('.tab-btn')].find((tab) => tab.textContent.trim() === 'All');
  if (allTab) {
    setTab(allTab, 'All');
    lucide.createIcons();
  }
}

function handleProtectedAction(label) {
  const destinationLabel = label || 'this section';
  const email = getSignedInEmail();
  if (!email) {
    redirectToLogin(`Please login before opening ${destinationLabel}.`, 'index.php');
    return false;
  }

  showToast(`Opening ${destinationLabel}...`);
  return true;
}

function openDashboard() {
  const email = getSignedInEmail();
  if (!email) {
    redirectToLogin('Please login to open your dashboard.', 'dashboard.php');
    return;
  }

  window.location.href = 'dashboard.php';
}

window.handleSignupPrompt = handleSignupPrompt;
window.handleLoginPrompt = handleLoginPrompt;
window.handleGetStartedAction = handleGetStartedAction;
window.handleBrowseCoursesAction = handleBrowseCoursesAction;
window.handleProtectedAction = handleProtectedAction;
window.openDashboard = openDashboard;

document.getElementById('mobileMenuBtn').addEventListener('click', function () {
  const nav = document.getElementById('mobileNav');
  nav.classList.toggle('open');
  const icon = this.querySelector('[data-lucide]');
  const isOpen = nav.classList.contains('open');
  icon.setAttribute('data-lucide', isOpen ? 'x' : 'menu');
  lucide.createIcons();
});

const defaultConfig = {
  site_name: 'EduSpark',
  hero_title: 'Learn Without Limits.',
  hero_subtitle: 'Master in-demand skills with expert-led courses, hands-on projects, and a global community of 2M+ learners. Your future starts today.',
  cta_button_text: 'Start Learning Free →',
  featured_courses_title: 'Featured Courses',
  stats_title: 'Our Impact in Numbers',
  background_color: '#0a0e1a',
  surface_color: '#111827',
  text_color: '#e8eaf0',
  accent_color: '#6c63ff',
  accent2_color: '#22d3a5',
};

window.elementSdk && window.elementSdk.init({
  defaultConfig,
  onConfigChange: async (config) => {
    const siteName = document.getElementById('site-name');
    if (siteName) {
      siteName.textContent = config.site_name || defaultConfig.site_name;
    }

    const heroTitle = document.getElementById('hero-title');
    if (heroTitle) {
      const parts = (config.hero_title || defaultConfig.hero_title).split(' ');
      const lastWord = parts.pop();
      heroTitle.innerHTML = `${parts.join(' ')}<br/><span class="highlight">${lastWord}</span>`;
    }

    const heroSubtitle = document.getElementById('hero-subtitle');
    if (heroSubtitle) {
      heroSubtitle.textContent = config.hero_subtitle || defaultConfig.hero_subtitle;
    }

    const ctaButton = document.getElementById('cta-button');
    if (ctaButton) {
      ctaButton.textContent = config.cta_button_text || defaultConfig.cta_button_text;
    }

    const featuredTitle = document.getElementById('featured-courses-title');
    if (featuredTitle) {
      featuredTitle.textContent = config.featured_courses_title || defaultConfig.featured_courses_title;
    }

    const statsTitle = document.getElementById('stats-title');
    if (statsTitle) {
      statsTitle.textContent = config.stats_title || defaultConfig.stats_title;
    }

    const bg = config.background_color || defaultConfig.background_color;
    const surf = config.surface_color || defaultConfig.surface_color;
    const txt = config.text_color || defaultConfig.text_color;
    const acc = config.accent_color || defaultConfig.accent_color;
    const acc2 = config.accent2_color || defaultConfig.accent2_color;

    document.documentElement.style.setProperty('--bg', bg);
    document.documentElement.style.setProperty('--surface', surf);
    document.documentElement.style.setProperty('--text', txt);
    document.documentElement.style.setProperty('--accent', acc);
    document.documentElement.style.setProperty('--accent2', acc2);

    document.body.style.backgroundColor = bg;
    document.body.style.color = txt;
  },
  mapToCapabilities: (config) => ({
    recolorables: [
      {
        get: () => config.background_color || defaultConfig.background_color,
        set: (value) => {
          config.background_color = value;
          window.elementSdk.setConfig({ background_color: value });
        },
      },
      {
        get: () => config.surface_color || defaultConfig.surface_color,
        set: (value) => {
          config.surface_color = value;
          window.elementSdk.setConfig({ surface_color: value });
        },
      },
      {
        get: () => config.text_color || defaultConfig.text_color,
        set: (value) => {
          config.text_color = value;
          window.elementSdk.setConfig({ text_color: value });
        },
      },
      {
        get: () => config.accent_color || defaultConfig.accent_color,
        set: (value) => {
          config.accent_color = value;
          window.elementSdk.setConfig({ accent_color: value });
        },
      },
      {
        get: () => config.accent2_color || defaultConfig.accent2_color,
        set: (value) => {
          config.accent2_color = value;
          window.elementSdk.setConfig({ accent2_color: value });
        },
      },
    ],
    borderables: [],
    fontEditable: undefined,
    fontSizeable: undefined,
  }),
  mapToEditPanelValues: (config) => new Map([
    ['site_name', config.site_name || defaultConfig.site_name],
    ['hero_title', config.hero_title || defaultConfig.hero_title],
    ['hero_subtitle', config.hero_subtitle || defaultConfig.hero_subtitle],
    ['cta_button_text', config.cta_button_text || defaultConfig.cta_button_text],
    ['featured_courses_title', config.featured_courses_title || defaultConfig.featured_courses_title],
    ['stats_title', config.stats_title || defaultConfig.stats_title],
  ]),
});

async function initApp() {
  renderCourses('All');
  lucide.createIcons();
  await hydrateFrontendFromBackend();
  await processPendingEnrollment();
}

initApp();