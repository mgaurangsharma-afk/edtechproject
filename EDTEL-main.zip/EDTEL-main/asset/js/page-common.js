const API_BASE = 'backend/api.php';
const USER_EMAIL_KEY = 'edtel_user_email';

function getSessionUser() {
    const candidate = window.__SESSION_USER__;
    if (!candidate || typeof candidate !== 'object') {
        return null;
    }

    const email = String(candidate.email || '').trim().toLowerCase();
    if (email === '') {
        return null;
    }

    return {
        name: String(candidate.name || '').trim(),
        email,
    };
}

function setSessionUser(user) {
    if (!user || typeof user !== 'object') {
        window.__SESSION_USER__ = null;
        localStorage.removeItem(USER_EMAIL_KEY);
        return;
    }

    const email = String(user.email || '').trim().toLowerCase();
    if (email === '') {
        window.__SESSION_USER__ = null;
        localStorage.removeItem(USER_EMAIL_KEY);
        return;
    }

    const normalized = {
        name: String(user.name || '').trim(),
        email,
    };

    window.__SESSION_USER__ = normalized;
    localStorage.setItem(USER_EMAIL_KEY, normalized.email);
}

function syncClientUserFromSession() {
    const sessionUser = getSessionUser();
    if (!sessionUser) {
        localStorage.removeItem(USER_EMAIL_KEY);
        return;
    }

    localStorage.setItem(USER_EMAIL_KEY, sessionUser.email);
}

syncClientUserFromSession();

function sanitizeRedirectTarget(target, fallback = 'dashboard.php') {
    if (!target) {
        return fallback;
    }

    const value = String(target).trim();
    if (value === '') {
        return fallback;
    }

    if (/^https?:\/\//i.test(value) || value.startsWith('//')) {
        return fallback;
    }

    return value;
}

function getCurrentUserEmail() {
    const sessionUser = getSessionUser();
    if (sessionUser) {
        return sessionUser.email;
    }

    return (localStorage.getItem(USER_EMAIL_KEY) || '').trim().toLowerCase();
}

function getCurrentUserName() {
    const sessionUser = getSessionUser();
    return sessionUser ? sessionUser.name : '';
}

function setCurrentUserEmail(email) {
    setSessionUser({
        name: getCurrentUserName(),
        email,
    });
}

function clearCurrentUserSession() {
    window.__SESSION_USER__ = null;
    localStorage.removeItem(USER_EMAIL_KEY);
}

function isUserLoggedIn() {
    return getCurrentUserEmail() !== '';
}

function getQueryParam(name) {
    return new URLSearchParams(window.location.search).get(name);
}

function buildCurrentPagePath() {
    const path = window.location.pathname.split('/').pop() || 'index.php';
    return `${path}${window.location.search}${window.location.hash}`;
}

function buildAuthUrl(page, message, redirectTarget) {
    const params = new URLSearchParams();

    if (message) {
        params.set('message', message);
    }

    if (redirectTarget) {
        params.set('redirect', sanitizeRedirectTarget(redirectTarget, 'index.php'));
    }

    const query = params.toString();
    return query ? `${page}?${query}` : page;
}

function redirectToLogin(message, redirectTarget) {
    const target = redirectTarget || buildCurrentPagePath();
    window.location.href = buildAuthUrl('login.php', message, target);
}

function redirectToSignup(message, redirectTarget) {
    const target = redirectTarget || buildCurrentPagePath();
    window.location.href = buildAuthUrl('signup.php', message, target);
}

function requireLoginAndGo(target, message = 'Please login to continue.') {
    if (!isUserLoggedIn()) {
        redirectToLogin(message, target || buildCurrentPagePath());
        return false;
    }

    window.location.href = sanitizeRedirectTarget(target, 'dashboard.php');
    return true;
}

async function fetchService(service, params = {}, options = {}) {
    const { method = 'GET', body = null } = options;
    const query = new URLSearchParams();
    query.set('service', service);

    Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
            query.set(key, String(value));
        }
    });

    const queryString = query.toString();
    const url = queryString ? `${API_BASE}?${queryString}` : API_BASE;
    const requestOptions = {
        method,
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
        },
    };

    if (body !== null) {
        requestOptions.headers['Content-Type'] = 'application/json';
        requestOptions.body = JSON.stringify(body);
    }

    const response = await fetch(url, requestOptions);

    let payload = null;
    try {
        payload = await response.json();
    } catch (error) {
        payload = null;
    }

    if (!response.ok || !payload || payload.ok === false) {
        const message = payload && typeof payload.message === 'string'
            ? payload.message
            : `Backend request failed with status ${response.status}`;
        throw new Error(message);
    }

    return payload;
}

function postService(service, payload) {
    return fetchService(service, {}, { method: 'POST', body: payload });
}

async function fetchProfile() {
    const payload = await fetchService('profile');
    const profile = payload && payload.data ? payload.data : null;
    setSessionUser(profile);
    return profile;
}

async function logoutUser(redirectTarget = 'index.php') {
    try {
        await postService('logout', {});
    } catch (error) {
        // Always continue with local cleanup and redirect.
    }

    clearCurrentUserSession();
    window.location.href = sanitizeRedirectTarget(redirectTarget, 'index.php');
}

window.appAuth = {
    sanitizeRedirectTarget,
    getSessionUser,
    setSessionUser,
    getCurrentUserName,
    getCurrentUserEmail,
    setCurrentUserEmail,
    clearCurrentUserSession,
    isUserLoggedIn,
    getQueryParam,
    buildCurrentPagePath,
    redirectToLogin,
    redirectToSignup,
    requireLoginAndGo,
    fetchService,
    postService,
    fetchProfile,
    logoutUser,
};

window.redirectToLogin = redirectToLogin;
window.redirectToSignup = redirectToSignup;
window.requireLoginAndGo = requireLoginAndGo;
