function resolveRedirectTarget() {
    const redirectQuery = appAuth.getQueryParam('redirect');
    const target = appAuth.sanitizeRedirectTarget(redirectQuery, 'dashboard.php');

    if (/^(login|signup)\.php($|[?#])/i.test(target)) {
        return 'dashboard.php';
    }

    return target;
}

const loginForm = document.getElementById('loginForm');
const loginStatus = document.getElementById('loginStatus');
const loginNotice = document.getElementById('loginNotice');
const loginSubmitBtn = document.getElementById('loginSubmitBtn');
const signupLink = document.getElementById('signupLink');
const loginEmailInput = document.getElementById('loginEmail');

const redirectTarget = resolveRedirectTarget();
const noticeMessage = appAuth.getQueryParam('message');

if (noticeMessage) {
    loginNotice.hidden = false;
    loginNotice.textContent = noticeMessage;
}

if (signupLink) {
    const params = new URLSearchParams();
    params.set('redirect', redirectTarget);
    signupLink.href = `signup.php?${params.toString()}`;
}

const existingUser = appAuth.getSessionUser ? appAuth.getSessionUser() : null;
const existingEmail = existingUser && existingUser.email
    ? String(existingUser.email).trim().toLowerCase()
    : appAuth.getCurrentUserEmail();
if (existingEmail) {
    loginEmailInput.value = existingEmail;
    loginStatus.textContent = `Already logged in as ${existingEmail}. Submit again to switch account.`;
}

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(loginForm);
    const email = String(formData.get('email') || '').trim().toLowerCase();
    const password = String(formData.get('password') || '');

    loginStatus.classList.remove('error');
    loginStatus.textContent = 'Checking credentials...';
    loginSubmitBtn.disabled = true;

    try {
        const payload = await appAuth.postService('login', {
            email,
            password,
        });

        const loggedInUser = payload && payload.data ? payload.data : { email };
        const loggedInEmail = loggedInUser && loggedInUser.email
            ? String(loggedInUser.email).trim().toLowerCase()
            : email;

        appAuth.setSessionUser({
            name: loggedInUser.name || '',
            email: loggedInEmail,
        });
        loginStatus.textContent = `Logged in as ${loggedInEmail}. Redirecting...`;

        setTimeout(() => {
            window.location.href = redirectTarget;
        }, 350);
    } catch (error) {
        loginStatus.textContent = error.message || 'Login failed.';
        loginStatus.classList.add('error');
    } finally {
        loginSubmitBtn.disabled = false;
    }
});
