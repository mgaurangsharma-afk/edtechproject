function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatDate(input) {
    if (!input) {
        return 'Saved recently';
    }

    const date = new Date(input);
    if (Number.isNaN(date.getTime())) {
        return 'Saved recently';
    }

    return date.toLocaleString();
}

const dashboardEmail = document.getElementById('dashboardEmail');
const selectedCount = document.getElementById('selectedCount');
const courseGrid = document.getElementById('courseGrid');
const emptyState = document.getElementById('emptyState');
const dashboardStatus = document.getElementById('dashboardStatus');
const refreshBtn = document.getElementById('refreshBtn');
const logoutBtn = document.getElementById('logoutBtn');

let currentEmail = appAuth.getCurrentUserEmail();

async function ensureDashboardUser() {
    if (currentEmail) {
        dashboardEmail.textContent = currentEmail;
        return true;
    }

    try {
        const profile = await appAuth.fetchProfile();
        currentEmail = profile && profile.email
            ? String(profile.email).trim().toLowerCase()
            : '';
    } catch (error) {
        currentEmail = '';
    }

    if (!currentEmail) {
        appAuth.redirectToLogin('Please login to view your dashboard.', 'dashboard.php');
        return false;
    }

    dashboardEmail.textContent = currentEmail;
    return true;
}

async function loadEnrollments() {
    const hasUser = await ensureDashboardUser();
    if (!hasUser) {
        return;
    }

    dashboardStatus.classList.remove('error');
    dashboardStatus.textContent = 'Loading your selected courses...';

    try {
        const payload = await appAuth.fetchService('enrollments');
        const enrollments = Array.isArray(payload.data) ? payload.data : [];

        selectedCount.textContent = String(enrollments.length);

        if (enrollments.length === 0) {
            courseGrid.innerHTML = '';
            emptyState.hidden = false;
            dashboardStatus.textContent = 'No courses selected yet.';
            return;
        }

        emptyState.hidden = true;
        courseGrid.innerHTML = enrollments.map((item) => {
            const title = escapeHtml(item.course_title || 'Untitled course');
            const courseId = escapeHtml(item.course_id || '-');
            const createdAt = escapeHtml(formatDate(item.created_at));
            const courseImage = escapeHtml(item.course_image || '');
            const courseVideo = escapeHtml(item.course_video || '');
            const mediaHtml = `
                    ${courseImage ? `<img class="course-media-image" src="${courseImage}" alt="${title}">` : ''}
                    ${courseVideo ? `<video class="course-media-video" controls preload="metadata" src="${courseVideo}" ${courseImage ? `poster="${courseImage}"` : ''}></video>` : ''}
                `;

            return `
        <article class="course-card">
          <h3>${title}</h3>
                    <div class="course-media">${mediaHtml}</div>
          <p>Course ID: ${courseId}</p>
          <p>Selected on: ${createdAt}</p>
        </article>
      `;
        }).join('');

        dashboardStatus.textContent = 'Selections loaded.';
    } catch (error) {
        dashboardStatus.textContent = error.message || 'Could not load your courses.';
        dashboardStatus.classList.add('error');
    }
}

refreshBtn.addEventListener('click', () => {
    loadEnrollments();
});

logoutBtn.addEventListener('click', () => {
    appAuth.logoutUser('index.php');
});

loadEnrollments();
